package com.noobmaster;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.ActionBarDrawerToggle;
import android.widget.LinearLayout;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ProgressBar;
import android.widget.EditText;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import android.content.Intent;
import android.net.Uri;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.ClipData;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.google.firebase.storage.OnProgressListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Continuation;
import java.io.File;
import android.view.View;
import android.widget.AdapterView;
import com.google.gson.Gson;
import android.content.ClipboardManager;
import com.bumptech.glide.Glide;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;

public class ChatActivity extends AppCompatActivity {
	
	public final int REQ_CD_FP = 101;
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	private FirebaseStorage _firebase_storage = FirebaseStorage.getInstance();
	
	private Toolbar _toolbar;
	private DrawerLayout _drawer;
	private HashMap<String, Object> map = new HashMap<>();
	private String username = "";
	private String profile_pic = "";
	private double limit = 0;
	private double n = 0;
	private double position = 0;
	private String linktext = "";
	private String path = "";
	private double likes = 0;
	private String user_path = "";
	private String temp_user = "";
	private String mytext = "";
	private String notif_path = "";
	private String notif_count = "";
	private String admin = "";
	
	private ArrayList<HashMap<String, Object>> all_chats = new ArrayList<>();
	private ArrayList<String> keys = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> users = new ArrayList<>();
	private ArrayList<String> uids = new ArrayList<>();
	private ArrayList<String> post_keys = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> notifications = new ArrayList<>();
	
	private ListView listview1;
	private LinearLayout linear2;
	private LinearLayout linear1;
	private ImageView imageview2;
	private TextView textview1;
	private ProgressBar progressbar1;
	private ImageView imageview1;
	private EditText edittext1;
	private ImageView send;
	private LinearLayout _drawer_linear1;
	private LinearLayout _drawer_linear2;
	private LinearLayout _drawer_linear3;
	private ImageView _drawer_profile_pic;
	private TextView _drawer_textview_user;
	private TextView _drawer_edit;
	private TextView _drawer_all_users;
	private TextView _drawer_logout_button;
	
	private DatabaseReference chat = _firebase.getReference("chat_path");
	private ChildEventListener _chat_child_listener;
	private FirebaseAuth fauth;
	private OnCompleteListener<AuthResult> _fauth_create_user_listener;
	private OnCompleteListener<AuthResult> _fauth_sign_in_listener;
	private OnCompleteListener<Void> _fauth_reset_password_listener;
	private Calendar cal = Calendar.getInstance();
	private Calendar now = Calendar.getInstance();
	private DatabaseReference user = _firebase.getReference("users");
	private ChildEventListener _user_child_listener;
	private Intent intent2 = new Intent();
	private Intent intent3 = new Intent();
	private AlertDialog.Builder dialogbox;
	private Intent fp = new Intent(Intent.ACTION_GET_CONTENT);
	private StorageReference fstore = _firebase_storage.getReference("fstore");
	private OnCompleteListener<Uri> _fstore_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _fstore_download_success_listener;
	private OnSuccessListener _fstore_delete_success_listener;
	private OnProgressListener _fstore_upload_progress_listener;
	private OnProgressListener _fstore_download_progress_listener;
	private OnFailureListener _fstore_failure_listener;
	private AlertDialog.Builder dialog;
	private DatabaseReference notif = _firebase.getReference("notification");
	private ChildEventListener _notif_child_listener;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.chat);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		_drawer = (DrawerLayout) findViewById(R.id._drawer);ActionBarDrawerToggle _toggle = new ActionBarDrawerToggle(ChatActivity.this, _drawer, _toolbar, R.string.app_name, R.string.app_name);
		_drawer.addDrawerListener(_toggle);
		_toggle.syncState();
		
		LinearLayout _nav_view = (LinearLayout) findViewById(R.id._nav_view);
		
		listview1 = (ListView) findViewById(R.id.listview1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		textview1 = (TextView) findViewById(R.id.textview1);
		progressbar1 = (ProgressBar) findViewById(R.id.progressbar1);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		edittext1 = (EditText) findViewById(R.id.edittext1);
		send = (ImageView) findViewById(R.id.send);
		_drawer_linear1 = (LinearLayout) _nav_view.findViewById(R.id.linear1);
		_drawer_linear2 = (LinearLayout) _nav_view.findViewById(R.id.linear2);
		_drawer_linear3 = (LinearLayout) _nav_view.findViewById(R.id.linear3);
		_drawer_profile_pic = (ImageView) _nav_view.findViewById(R.id.profile_pic);
		_drawer_textview_user = (TextView) _nav_view.findViewById(R.id.textview_user);
		_drawer_edit = (TextView) _nav_view.findViewById(R.id.edit);
		_drawer_all_users = (TextView) _nav_view.findViewById(R.id.all_users);
		_drawer_logout_button = (TextView) _nav_view.findViewById(R.id.logout_button);
		fauth = FirebaseAuth.getInstance();
		dialogbox = new AlertDialog.Builder(this);
		fp.setType("image/*");
		fp.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		dialog = new AlertDialog.Builder(this);
		
		listview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				intent3.setClass(getApplicationContext(), PostDataActivity.class);
				intent3.putExtra("postID", keys.get((int)(_position)));
				map = all_chats.get((int)_position);
				intent3.putExtra("post", new Gson().toJson(map));
				startActivity(intent3);
			}
		});
		
		listview1.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
			@Override
			public boolean onItemLongClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				PopupMenu popup = new PopupMenu(ChatActivity.this, _param2);
				Menu menu = popup.getMenu();
				menu.add("Copiar");
				if (all_chats.get((int)_position).get("username").toString().equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					menu.add("Editar");
					menu.add("Deletar");
				}
				popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener(){
					@Override
					public boolean onMenuItemClick(MenuItem item){
						
						switch (item.getTitle().toString()){
							case "Editar":
							dialog.setTitle("Editar");
							final EditText myedittext = new EditText (ChatActivity.this);
							dialog.setView(myedittext);
							dialog.setPositiveButton("Salvar", new DialogInterface.OnClickListener() {
								@Override
								public void onClick(DialogInterface _dialog, int _which) {
									mytext = myedittext.getText().toString();
									map = new HashMap<>();
									map.put("text", mytext);
									chat.child(keys.get((int)(_position))).updateChildren(map);
								}
							});
							dialog.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
								@Override
								public void onClick(DialogInterface _dialog, int _which) {
									
								}
							});
							dialog.create().show();
							break;
							case "Deletar":
							if (all_chats.get((int)_position).containsKey("image")) {
								_firebase_storage.getReferenceFromUrl(all_chats.get((int)_position).get("image").toString()).delete().addOnSuccessListener(_fstore_delete_success_listener).addOnFailureListener(_fstore_failure_listener);
							}
							else {
								
							}
							chat.child(keys.get((int)(_position))).removeValue();
							break;
							case "Copiar":
							((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", all_chats.get((int)_position).get("text").toString()));
							break;}
						return true;
					}
				});
				popup.show();
				return true;
			}
		});
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				startActivityForResult(fp, REQ_CD_FP);
			}
		});
		
		send.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (edittext1.getText().toString().length() > 0) {
					position = 0;
					if (path.equals("")) {
						now = Calendar.getInstance();
						map = new HashMap<>();
						map.put("username", FirebaseAuth.getInstance().getCurrentUser().getUid());
						map.put("text", edittext1.getText().toString());
						map.put("time", String.valueOf((long)(now.getTimeInMillis())));
						chat.push().updateChildren(map);
						edittext1.setText("");
					}
					else {
						fstore.child(Uri.parse(path).getLastPathSegment()).putFile(Uri.fromFile(new File(path))).addOnFailureListener(_fstore_failure_listener).addOnProgressListener(_fstore_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
							@Override
							public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
								return fstore.child(Uri.parse(path).getLastPathSegment()).getDownloadUrl();
							}}).addOnCompleteListener(_fstore_upload_success_listener);
						progressbar1.setVisibility(View.VISIBLE);
						send.setEnabled(false);
					}
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), "Digite algo para enviar! ");
				}
			}
		});
		
		_chat_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		chat.addChildEventListener(_chat_child_listener);
		
		_user_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		user.addChildEventListener(_user_child_listener);
		
		_fstore_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_fstore_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_fstore_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				path = "";
				textview1.setVisibility(View.GONE);
				progressbar1.setVisibility(View.GONE);
				send.setEnabled(true);
				now = Calendar.getInstance();
				map = new HashMap<>();
				map.put("username", FirebaseAuth.getInstance().getCurrentUser().getUid());
				map.put("text", edittext1.getText().toString());
				map.put("time", String.valueOf((long)(now.getTimeInMillis())));
				map.put("image", _downloadUrl);
				chat.push().updateChildren(map);
				edittext1.setText("");
				SketchwareUtil.showMessage(getApplicationContext(), "Imagem enviada com sucesso !");
				textview1.setText("");
				linear2.setVisibility(View.GONE);
			}
		};
		
		_fstore_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				
			}
		};
		
		_fstore_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				SketchwareUtil.showMessage(getApplicationContext(), "Imagem deletada");
			}
		};
		
		_fstore_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				progressbar1.setVisibility(View.GONE);
				send.setEnabled(true);
				SketchwareUtil.showMessage(getApplicationContext(), _message);
			}
		};
		
		_notif_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				notif.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						notifications = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								notifications.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						notif_count = String.valueOf((long)(notifications.size()));
						invalidateOptionsMenu();
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		notif.addChildEventListener(_notif_child_listener);
		
		_drawer_edit.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent2.setClass(getApplicationContext(), ProfileActivity.class);
				intent2.putExtra("username", username);
				intent2.putExtra("profile_pic", profile_pic);
				startActivity(intent2);
			}
		});
		
		_drawer_all_users.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent3.setClass(getApplicationContext(), AllusersActivity.class);
				intent3.putExtra("user1name", username);
				intent3.putExtra("user1pic", profile_pic);
				startActivity(intent3);
			}
		});
		
		_drawer_logout_button.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				FirebaseAuth.getInstance().signOut();
				finish();
			}
		});
		
		_fauth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_fauth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_fauth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	private void initializeLogic() {
		notif_count = "0";
		invalidateOptionsMenu();
		textview1.setText("");
		textview1.setVisibility(View.GONE);
		progressbar1.setVisibility(View.GONE);
		imageview2.setVisibility(View.GONE);
		limit = 30;
		chat.removeEventListener(_chat_child_listener);
		user.removeEventListener(_user_child_listener);
		notif.removeEventListener(_notif_child_listener);
		listview1.setTranscriptMode(ListView.TRANSCRIPT_MODE_NORMAL);
		listview1.setStackFromBottom(true);
		listview1.setOnScrollListener(new AbsListView.OnScrollListener() {
			
			public void onScrollStateChanged(AbsListView view, int scrollState) {
				if (all_chats.size() >9){
					if (scrollState==0){
						if (listview1.getFirstVisiblePosition()==0){
							if (!(limit > all_chats.size())) {
								limit = all_chats.size() + 30;
								position = all_chats.size();
								chat.limitToLast((int)limit).addValueEventListener(valuelistener1);
							}
						}
					}
				}
			}
			
			public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
				
			}
		});
		chat.limitToLast((int)limit).addValueEventListener(valuelistener1);
		admin = "users/".concat(FirebaseAuth.getInstance().getCurrentUser().getUid());
		user = _firebase.getReference(admin);
		user.addListenerForSingleValueEvent(valuelistener3);
		notif_path = "users/".concat(FirebaseAuth.getInstance().getCurrentUser().getUid().concat("/".concat("notifications")));
		notif = _firebase.getReference(notif_path);
		notif.addChildEventListener(_notif_child_listener);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			case REQ_CD_FP:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				path = _filePath.get((int)(0));
				textview1.setVisibility(View.VISIBLE);
				textview1.setText(path);
				imageview2.setVisibility(View.VISIBLE);
				imageview2.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(path, 1024, 1024));
			}
			else {
				
			}
			break;
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		if (_drawer.isDrawerOpen(GravityCompat.START)) {
			_drawer.closeDrawer(GravityCompat.START);
		}
		else {
			super.onBackPressed();
		}
	}
	private void _extra () {
	}
	ValueEventListener valuelistener1 = new ValueEventListener() {
		@Override
		public void onDataChange(DataSnapshot _param1) {
			try {
				all_chats.clear();
				keys.clear();
				users.clear();
				uids.clear();
				GenericTypeIndicator < HashMap< String, Object>> _ind = new GenericTypeIndicator<HashMap< String, Object>>() {};
				
				for (DataSnapshot _data : _param1.getChildren()) {
					keys.add(_data.getKey());
					HashMap <String, Object> _map= _data.getValue(_ind);
					all_chats.add(_map);
					
					temp_user = _map.get("username").toString();
					user_path = "users/".concat(temp_user);
					user = _firebase.getReference(user_path);
					
					user.addValueEventListener(valuelistener2);
				}
				limit = all_chats.size();
			} catch (Exception e) {
				showMessage(e.toString()); }
		}
		
		@Override
		public void onCancelled(DatabaseError databaseError) { }
	};
	
	ValueEventListener valuelistener2 = new ValueEventListener() {
		@Override
		public void onDataChange(DataSnapshot _param1) {
			GenericTypeIndicator < HashMap< String, Object>> _ind = new GenericTypeIndicator<HashMap< String, Object>>() {};
			try {
				if (!uids.contains(_param1.getKey())){
					uids.add(_param1.getKey());
					
					HashMap <String, Object> _map= _param1.getValue(_ind);
					users.add(_map);
					
				}
				edittext1.setHint(String.valueOf((long)(all_chats.size())).concat(",").concat(String.valueOf((long)(users.size())).concat(",".concat(String.valueOf((long)(uids.size()))))));
				listview1.setAdapter(new Listview1Adapter(all_chats));
				((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
				listview1.setSelection(all_chats.size() - (int)position);
			} catch (Exception e) {
				showMessage(e.toString()); }
		}
		
		@Override
		public void onCancelled(DatabaseError databaseError) { }
	};
	
	ValueEventListener valuelistener3 = new ValueEventListener() {
		@Override
		public void onDataChange(DataSnapshot _param1) {
			GenericTypeIndicator < HashMap< String, Object>> _ind = new GenericTypeIndicator<HashMap< String, Object>>() {};
			try {
				HashMap <String, Object> _map= _param1.getValue(_ind);
				
				if (_map.containsKey("pic")){
					profile_pic = _map.get("pic").toString();
				}
				
				username = _map.get("username").toString();
				com.bumptech.glide.Glide.with(getApplicationContext()).load(Uri.parse(profile_pic)).into(_drawer_profile_pic);
				
				_drawer_textview_user.setText(username);
			} catch (Exception e) {
				showMessage(e.toString()); }
		}
		
		@Override
		public void onCancelled(DatabaseError databaseError) { }
	};
	{
	}
	
	
	private void _extra2 () {
	}
	
	private static final int NOTIF = 1;
	 @Override
	public boolean onCreateOptionsMenu(Menu menu) {
		menu.add(Menu.NONE, NOTIF, 0, notif_count).setIcon(R.drawable.ic_notifications_white).setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
		return true;
	}
	 @Override
	public boolean onPrepareOptionsMenu(Menu menu) {
		menu.findItem(NOTIF).setTitle(notif_count);
		
		return super.onPrepareOptionsMenu(menu);
	}
	 @Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
			case NOTIF:
			intent3.setClass(getApplicationContext(), NotificationsActivity.class);
			intent3.putExtra("user1name", username);
			intent3.putExtra("user1pic", profile_pic);
			startActivity(intent3);
			return true;
			default: return false; }
	}
	
	
	public class Listview1Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _view, ViewGroup _viewGroup) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _view;
			if (_v == null) {
				_v = _inflater.inflate(R.layout.custom, null);
			}
			
			final LinearLayout linear10 = (LinearLayout) _v.findViewById(R.id.linear10);
			final LinearLayout lin5 = (LinearLayout) _v.findViewById(R.id.lin5);
			final LinearLayout linear8 = (LinearLayout) _v.findViewById(R.id.linear8);
			final LinearLayout linear3 = (LinearLayout) _v.findViewById(R.id.linear3);
			final ImageView imageview1 = (ImageView) _v.findViewById(R.id.imageview1);
			final LinearLayout linear4 = (LinearLayout) _v.findViewById(R.id.linear4);
			final LinearLayout linear5 = (LinearLayout) _v.findViewById(R.id.linear5);
			final TextView textview1 = (TextView) _v.findViewById(R.id.textview1);
			final ImageView imageview3 = (ImageView) _v.findViewById(R.id.imageview3);
			final TextView textview4 = (TextView) _v.findViewById(R.id.textview4);
			final ImageView imageview2 = (ImageView) _v.findViewById(R.id.imageview2);
			final TextView textview5 = (TextView) _v.findViewById(R.id.textview5);
			final TextView textview2 = (TextView) _v.findViewById(R.id.textview2);
			final TextView text_time = (TextView) _v.findViewById(R.id.text_time);
			final ImageView esc = (ImageView) _v.findViewById(R.id.esc);
			final LinearLayout linear9 = (LinearLayout) _v.findViewById(R.id.linear9);
			final ImageView dir = (ImageView) _v.findViewById(R.id.dir);
			
			esc.setVisibility(View.GONE);
			dir.setVisibility(View.GONE);
			android.graphics.drawable.GradientDrawable gdq2 = new android.graphics.drawable.GradientDrawable();
			gdq2.setColor(Color.parseColor("#F5F5F5"));
			gdq2.setCornerRadius(5);
			linear3.setBackground(gdq2);
			LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
			lp.weight=1;
			_viewGroup.setLayoutParams(lp);
			if (all_chats.get((int)_position).containsKey("username")) {
				if (uids.contains(all_chats.get((int)_position).get("username").toString())) {
					if (users.get((int)uids.indexOf(all_chats.get((int)_position).get("username").toString())) == null){
						textview1.setText(all_chats.get((int)_position).get("username").toString());
						map = new HashMap<>();
						map.put("username", "Usuário anônimo ");
						user = _firebase.getReference("users");
						
						user.addValueEventListener(valuelistener2);
						user.child(all_chats.get((int)_position).get("username").toString()).updateChildren(map);
					} else {
						textview1.setText(users.get((int)uids.indexOf(all_chats.get((int)_position).get("username").toString())).get("username").toString());
					}
				}
				else {
					textview1.setText(all_chats.get((int)_position).get("username").toString());
				}
				if (all_chats.get((int)_position).get("username").toString().equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					dir.setVisibility(View.VISIBLE);
					android.graphics.drawable.GradientDrawable gd2 = new android.graphics.drawable.GradientDrawable();
					gd2.setColor(Color.parseColor("#CDCDC1"));
					gd2.setCornerRadius(2);
					lin5.setBackground(gd2);
					((LinearLayout)_v).setGravity(Gravity.RIGHT);
				}
				else {
					esc.setVisibility(View.VISIBLE);
					android.graphics.drawable.GradientDrawable gd2 = new android.graphics.drawable.GradientDrawable();
					gd2.setColor(Color.parseColor("#C1CDC1"));
					gd2.setCornerRadius(2);
					lin5.setBackground(gd2);
					((LinearLayout)_v).setGravity(Gravity.LEFT);
				}
			}
			if (all_chats.get((int)_position).containsKey("text")) {
				textview2.setText(all_chats.get((int)_position).get("text").toString());
			}
			if (all_chats.get((int)_position).containsKey("time")) {
				cal.setTimeInMillis((long)(Double.parseDouble(all_chats.get((int)_position).get("time").toString())));
				now = Calendar.getInstance();
				if ((long)(now.getTimeInMillis() - cal.getTimeInMillis()) > (1000 * (3600 * 12))) {
					text_time.setText(new SimpleDateFormat("dd MMM yy").format(cal.getTime()));
				}
				else {
					text_time.setText(new SimpleDateFormat("hh:mm a").format(cal.getTime()));
				}
			}
			textview1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					intent3.setClass(getApplicationContext(), PrivateChatActivity.class);
					intent3.putExtra("user2", all_chats.get((int)_position).get("username").toString());
					intent3.putExtra("user2name", textview1.getText().toString());
					if (users.get((int)uids.indexOf(all_chats.get((int)_position).get("username").toString())).containsKey("pic")) {
						intent3.putExtra("user2pic", users.get((int)uids.indexOf(all_chats.get((int)_position).get("username").toString())).get("pic").toString());
					}
					else {
						intent3.putExtra("user2pic", "");
					}
					intent3.putExtra("user1name", username);
					intent3.putExtra("user1pic", profile_pic);
					startActivity(intent3);
				}
			});
			if (all_chats.get((int)_position).containsKey("image")) {
				imageview1.setVisibility(View.VISIBLE);
				Glide.with(getApplicationContext()).load(Uri.parse(all_chats.get((int)_position).get("image").toString())).into(imageview1);
			}
			else {
				imageview1.setVisibility(View.GONE);
			}
			if (all_chats.get((int)_position).containsKey("visits")) {
				textview4.setText(all_chats.get((int)_position).get("visits").toString());
			}
			else {
				textview4.setText("0");
			}
			map = all_chats.get((int)_position);
			SketchwareUtil.getAllKeysFromMap(map, post_keys);
			n = 0;
			likes = 0;
			for(int _repeat248 = 0; _repeat248 < (int)(post_keys.size()); _repeat248++) {
				if (map.get(post_keys.get((int)(n))).toString().equals("true")) {
					likes++;
				}
				n++;
			}
			textview5.setText(String.valueOf((long)(likes)));
			if (map.containsKey(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
				if (map.get(FirebaseAuth.getInstance().getCurrentUser().getUid()).toString().equals("true")) {
					imageview2.setColorFilter(0xFFF44336, PorterDuff.Mode.MULTIPLY);
				}
				else {
					imageview2.setColorFilter(0xFF212121, PorterDuff.Mode.MULTIPLY);
				}
			}
			else {
				imageview2.setColorFilter(0xFF757575, PorterDuff.Mode.MULTIPLY);
			}
			imageview2.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					map = new HashMap<>();
					if (all_chats.get((int)_position).containsKey(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
						if (all_chats.get((int)_position).get(FirebaseAuth.getInstance().getCurrentUser().getUid()).toString().equals("true")) {
							map.put(FirebaseAuth.getInstance().getCurrentUser().getUid(), "false");
						}
						else {
							map.put(FirebaseAuth.getInstance().getCurrentUser().getUid(), "true");
						}
					}
					else {
						map.put(FirebaseAuth.getInstance().getCurrentUser().getUid(), "true");
					}
					chat.child(keys.get((int)(_position))).updateChildren(map);
				}
			});
			
			return _v;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
